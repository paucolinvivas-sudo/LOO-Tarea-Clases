using System;

class Empleado
{
    string nombre, apellido;
    double salariom, salarioa;

    public Empleado()
    {
        nombre = "";
        apellido = "";
        salariom = 0.0;
        salarioa = 0.0;
    }

    public void preguntar()
    {
        Console.WriteLine("Ingresa el nombre del empleado");
        nombre = Console.ReadLine();

        Console.WriteLine("Ingresa el apellido del empleado");
        apellido = Console.ReadLine();

        Console.WriteLine("Ingresa el salario del empleado");
        salariom = Convert.ToDouble(Console.ReadLine());

        if (salariom <= 0)
        {
            salariom = 0.0;
        }

        salarioa = salariom * 12;
    }

    public double aumento()
    {
        return salarioa * (10.0 / 100.0);
    }

    public void imprimir()
    {
        Console.WriteLine("Nombre del empleado/a: " + nombre);
        Console.WriteLine("Apellido del empleado/a: " + apellido);
        Console.WriteLine("Salario mensual del empleado/a: " + salariom);
        Console.WriteLine("Salario anual del empleado/a: " + salarioa);
        Console.WriteLine("Aumento en el salario anual: " + aumento());
    }
}

class EmpleadoTest
{
    static void Main(string[] args)
    {
        Empleado empleado1 = new Empleado();

        Console.WriteLine("Empleado 1");

        empleado1.preguntar();
        empleado1.imprimir();

        Empleado empleado2 = new Empleado();

        Console.WriteLine("Empleado 2");

        empleado2.preguntar();
        empleado2.imprimir();
    }
}
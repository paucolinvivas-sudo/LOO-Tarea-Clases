#include <iostream>
using namespace std;

class Fecha {
    
public:
    
    int mes, dia, año;
    
    Fecha() {
        mes=8;
        dia=27;
        año=2026;
    }
    
    void mostrarFecha() {
        cout<<dia<<"/"<<mes<<"/"<<año<<endl;
    }
};

class FechaTest {
    
public:
    
    void probarFecha() {
        Fecha fecha;
        
        cout<<"La fecha de hoy es: "<<endl;
        fecha.mostrarFecha();
    }
};

int main()
{
    FechaTest prueba;
    
    prueba.probarFecha();

    return 0;
}
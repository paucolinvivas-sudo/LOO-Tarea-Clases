class Empleado:

    def __init__(self):
        self.nombre = ""
        self.apellido = ""
        self.salariom = 0.0
        self.salarioa = 0.0

    def preguntar(self):
        print("Ingresa el nombre del empleado")
        self.nombre = input()

        print("Ingresa el apellido del empleado")
        self.apellido = input()

        print("Ingresa el salario del empleado")
        self.salariom = float(input())

        if self.salariom <= 0:
            self.salariom = 0.0

        self.salarioa = self.salariom * 12

    def aumento(self):
        return self.salarioa * (10.0 / 100.0)

    def imprimir(self):
        print("Nombre del empleado/a:", self.nombre)
        print("Apellido del empleado/a:", self.apellido)
        print("Salario mensual del empleado/a:", self.salariom)
        print("Salario anual del empleado/a:", self.salarioa)
        print("Aumento en el salario anual:", self.aumento())


empleado1 = Empleado()

print("Empleado 1")

empleado1.preguntar()
empleado1.imprimir()

empleado2 = Empleado()

print("Empleado 2")

empleado2.preguntar()
empleado2.imprimir()
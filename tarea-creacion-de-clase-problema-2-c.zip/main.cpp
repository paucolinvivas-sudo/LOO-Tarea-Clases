#include <iostream>
#include <string>
using namespace std;

class Empleado
{
    string nombre, apellido;
    double salariom, salarioa;

public:

    Empleado()
    {
        nombre = "";
        apellido = "";
        salariom = 0.0;
        salarioa = 0.0;
    }

    void preguntar()
    {
        cout << "Ingresa el nombre del empleado" << endl;
        getline(cin, nombre);

        cout << "Ingresa el apellido del empleado" << endl;
        getline(cin, apellido);

        cout << "Ingresa el salario del empleado" << endl;
        cin >> salariom;
        cin.ignore();

        if (salariom <= 0)
        {
            salariom = 0.0;
        }

        salarioa = salariom * 12;
    }

    double aumento()
    {
        return salarioa * (10.0 / 100.0);
    }

    void imprimir()
    {
        cout << "Nombre del empleado/a: " << nombre << endl;
        cout << "Apellido del empleado/a: " << apellido << endl;
        cout << "Salario mensual del empleado/a: " << salariom << endl;
        cout << "Salario anual del empleado/a: " << salarioa << endl;
        cout << "Aumento en el salario anual: " << aumento() << endl;
    }
};

int main()
{
    Empleado empleado1;

    cout << "Empleado 1" << endl;

    empleado1.preguntar();
    empleado1.imprimir();

    Empleado empleado2;

    cout << "Empleado 2" << endl;

    empleado2.preguntar();
    empleado2.imprimir();

    return 0;
}


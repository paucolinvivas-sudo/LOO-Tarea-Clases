class Factura:
    #atributos inicializados en el constructor __init__
    def __init__(self):
        self.numpieza = ""
        self.descripcion = ""
        self.cantidad = 0
        self.precio = 0.0
        
    def obtenermontofactura(self):
        return self.cantidad*self.precio
        
#FacturaTest
ferre = Factura()

ferre.numpieza = input("Ingresa el número de pieza: ")
ferre.descripcion = input("Descripción: ")
ferre.cantidad = int(input("Cantidad: "))
ferre.precio = float(input("Precio: "))

ferre.cantidad = 0 if ferre.cantidad < 0 else ferre.cantidad
ferre.precio =
0.0 if ferre.precio < 0 else ferre.precio

print ("Factura: ",  ferre.obtenermontofactura())
            
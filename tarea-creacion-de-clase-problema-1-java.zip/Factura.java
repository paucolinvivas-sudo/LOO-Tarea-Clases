public class Factura
{
    //Atributos (variables instancias)
    String numPieza;
    String descripción;
    int cantidad;
    double precio;
    
    //el constructor tiene el mismo nombre de la clase 
    Factura() { //constructor que inicializa las 4 variables instancias
        numPieza = "";
        descripción = "";
        cantidad = 0;
        precio = 0.0;
        
    }
    
    double obtenerMontoFactura(){
        return cantidad*precio;
    }
    
}

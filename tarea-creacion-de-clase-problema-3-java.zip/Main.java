class Fecha
{
    
    public int mes, dia, año;
    
    public Fecha()
    {
        mes=8;
        dia=27;
        año=2026;
    }
    
    public void mostrarFecha()
    {
        System.out.println(dia+"/"+mes+"/"+año);
    }
}

class FechaTest
{
    
    public void probarFecha()
    {
        Fecha fecha = new Fecha();
        
        System.out.println("La fecha de hoy es: ");
        fecha.mostrarFecha();
    }
}

public class Main
{
    public static void main(String[] args)
    {
        FechaTest prueba = new FechaTest();
        
        prueba.probarFecha();
    }
}
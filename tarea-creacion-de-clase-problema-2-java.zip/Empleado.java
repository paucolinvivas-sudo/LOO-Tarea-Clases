import java.util.Scanner;
class Empleado
{
    Scanner input = new Scanner(System.in);
    String nombre, apellido;
    double salariom, salarioa;
    
    Empleado(){
        nombre="";
        apellido="";
        salariom=0.0;
        salarioa=0.0;
    }
    
    void preguntar(){
        System.out.println("Ingresa el nombre del empleado");
        nombre=input.nextLine();
        System.out.println("Ingresa el apellido del empleado");
        apellido=input.nextLine();
        System.out.println("Ingresa el salario del empleado");
        salariom=input.nextDouble();
    
        if(salariom<=0){
            salariom=0.0;
        }
    
        salarioa=salariom*12;
    }
    
    double aumento(){
        return salarioa*(10.0/100.0);
    }
    
    void imprimir(){
        System.out.println("Nombre del empleado/a: "+nombre);
        System.out.println("Apellido del empleado/a: "+apellido);
        System.out.println("Salario mensual del empleado/a: "+salariom);
        System.out.println("Salario anual del empleado/a: "+salarioa);
        System.out.println("Aumento en el salario anual: "+aumento());
    }
    

}
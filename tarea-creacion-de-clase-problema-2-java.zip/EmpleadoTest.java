import java.util.Scanner;
public class EmpleadoTest{
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    Empleado empleado1 = new Empleado();
    System.out.println("Empleado 1");

    empleado1.preguntar();
    empleado1.imprimir();
    
    
    Empleado empleado2=new Empleado();
    System.out.println("Empleado 2");
    
    empleado2.preguntar();
    empleado2.imprimir();
    
    }
}
#include <iostream>
using namespace std;
class Factura {
    
public:
    
    string numpieza, descripcion;
    int cantidad;
    double precio;
    
    Factura() {
        numpieza="";
        descripcion="";
        cantidad=0;
        precio=0.0;
    }
    double obtenermontofactura(){
        return cantidad*precio;
    }
    
    void imprimir() {
        cout<<"Numero de pieza: "<<numpieza<<endl;
        cout<<"Descripción: "<<descripcion<<endl;
        cout<<"Cantidad: "<<cantidad<<endl;
        cout<<"Precio: "<<precio<<endl;
    }
};

int main()
{
    Factura ferre;
    cout<<"Ingresa el numero de pieza: "<<endl;
    cin>>ferre.numpieza;
    cout<<"Descripción: "<<endl;
    cin>>ferre.descripcion;
    cout<<"Cantidad: "<<endl;
    cin>>ferre.cantidad;
    cout<<"Precio: "<<endl;
    cin>>ferre.precio;
    
    if (ferre.cantidad <=0){
        ferre.cantidad = 0;
    }
    if(ferre.precio<=0){
        ferre.precio=0.0;
    }
    
    ferre.imprimir();
    ferre.obtenermontofactura();
    

    return 0;
}


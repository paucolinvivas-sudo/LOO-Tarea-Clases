using System;

class Factura
{
    // Atributos (variables instancias)
    public string numPieza;
    public string descripción;
    public int cantidad;
    public double precio;

    // Constructor
    public Factura()
    {
        numPieza = "";
        descripción = "";
        cantidad = 0;
        precio = 0.0;
    }

    public double obtenerMontoFactura()
    {
        return cantidad * precio;
    }
}

class FacturaTest
{
    static void Main()
    {
        Factura ferre = new Factura();

        Console.WriteLine("Ingresa el numero de pieza: ");
        ferre.numPieza = Console.ReadLine();

        Console.WriteLine("Agrega descripción: ");
        ferre.descripción = Console.ReadLine();

        Console.WriteLine("Cantidad: ");
        ferre.cantidad = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Precio: ");
        ferre.precio = Convert.ToDouble(Console.ReadLine());

        if (ferre.precio < 0)
            ferre.precio = 0.0;

        if (ferre.cantidad < 0)
            ferre.cantidad = 0;

        Console.WriteLine("Factura: " + ferre.obtenerMontoFactura());
    }
}
using System;

class Fecha
{
    
    public int mes, dia, año;
    
    public Fecha()
    {
        mes=8;
        dia=27;
        año=2026;
    }
    
    public void mostrarFecha()
    {
        Console.WriteLine(dia+"/"+mes+"/"+año);
    }
}

class FechaTest
{
    
    public void probarFecha()
    {
        Fecha fecha = new Fecha();
        
        Console.WriteLine("La fecha de hoy es: ");
        fecha.mostrarFecha();
    }
}

class Program
{
    static void Main()
    {
        FechaTest prueba = new FechaTest();
        
        prueba.probarFecha();
    }
}
class Fecha:
    
    def __init__(self):
        self.mes=8
        self.dia=27
        self.año=2026
    
    def mostrarFecha(self):
        print(self.dia, "/", self.mes, "/", self.año, sep="")


class FechaTest:
    
    def probarFecha(self):
        fecha=Fecha()
        
        print("La fecha de hoy es: ")
        fecha.mostrarFecha()


prueba=FechaTest()

prueba.probarFecha()